# baixiu-docs

baixiu proj documents

## Table of Content

01. [相关介绍](01-introduction.md)
02. [准备工作](02-getting-started.md)
03. [管理后台登录](03-admin-login.md)
04. [管理后台仪表板](04-admin-dashboard.md)
05. [管理后台文章列表](05-admin-post-list.md)
06. [管理后台删除文章](06-admin-post-delete.md)
07. [管理后台新增文章](07-admin-post-add.md)
08. [管理后台分类管理](08-admin-category.md)
09. [管理后台评论管理](09-admin-comment.md)
10. [管理后台用户管理](10-admin-user.md)
11. [管理后台配置选项](11-admin-options.md)
12. [管理后台导航菜单管理](12-admin-nav-menu.md)
13. [管理后台首页轮播管理](13-admin-slide.md)
14. [管理后台设置选项](14-admin-setting.md)
