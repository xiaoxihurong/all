<template>
    <div>
        <h1>搜索</h1>
    </div>
</template>

<script>
export default {
    
}
</script>

<style scoped>

</style>