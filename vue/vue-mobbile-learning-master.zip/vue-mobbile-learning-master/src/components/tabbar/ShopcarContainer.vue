<template>
    <div>
        <h1>购物车</h1>
    </div>
</template>

<script>
export default {
    
}
</script>

<style scoped>

</style>